//: Playground - noun: a place where people can play

import UIKit


struct Point {
    var X: Double
    var Y: Double
}


struct Line {
    var Start:Point
    var End:Point
    func countLength()->Double{
        let xDist=(End.X-Start.X)
        let yDist=(End.Y-Start.Y)
        return (sqrt((xDist * xDist) + (yDist * yDist)))
    }
}

var l = Line(Start:Point(X:1,Y:1),End:Point(X:2,Y:3))

print(l.countLength())


struct Triangle {
    var arr:[Point]=[]
    func countArea()->Double{
        return  abs((arr[0].X*arr[1].Y+arr[1].X*arr[2].Y+arr[2].X*arr[0].Y-arr[0].Y*arr[1].X-arr[1].Y*arr[2].X-arr[2].Y*arr[0].X)/2)
        
    }
    
}


var t=Triangle(arr:[Point(X:-2,Y:3),Point(X:-3,Y:-1),Point(X:3,Y:-2)]).countArea()





